var searchData=
[
  ['win32file_5fiowin',['WIN32FILE_IOWIN',['../struct_w_i_n32_f_i_l_e___i_o_w_i_n.html',1,'']]],
  ['winfotable_5fcreatefromjsonforeachparams',['wInfoTable_CreateFromJsonForEachParams',['../structw_info_table___create_from_json_for_each_params.html',1,'']]]
];
