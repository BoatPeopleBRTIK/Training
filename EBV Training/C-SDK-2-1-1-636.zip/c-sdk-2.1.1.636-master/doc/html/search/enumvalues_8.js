var searchData=
[
  ['server_5fclosed',['SERVER_CLOSED',['../tw_websocket_8h.html#a16c0d744619c0e4c04084ca3e8ab89d9a03821ca6aaf10d22fe9e3ec2d7bf076e',1,'twWebsocket.h']]]
];
