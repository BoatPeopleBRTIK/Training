var searchData=
[
  ['_5fcurrent',['_current',['../class_dot_z_lib_1_1_checksum_generator_base.html#ae7a9bb3eb75ea23a06dbaa4c52503f4a',1,'DotZLib::ChecksumGeneratorBase']]],
  ['_5fisdisposed',['_isDisposed',['../class_dot_z_lib_1_1_codec_base.html#a9aa2d3961669aad672e43946c25ae24b',1,'DotZLib::CodecBase']]]
];
